import Image from "next/image";

export default function Home() {
  return (
    <div>
      <div className="flex justify-center items-center h-screen">
        <h1 className="text-3xl ">Red Playground</h1>
      </div>
    </div>
  );
}
